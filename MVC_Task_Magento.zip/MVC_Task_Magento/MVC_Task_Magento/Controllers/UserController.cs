﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_Task_Magento.Models;

namespace MVC_Task_Magento.Controllers
{
    public class UserController : Controller
    {
        FormTaskDBMagentoEntities db;
        public UserController()
        {
            db = new FormTaskDBMagentoEntities();
        }
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult create()
        {
            return View();
        }
        public string AddrecodDB(user_info u)
        {
            db.user_info.Add(u);
            db.SaveChanges();
            return "Record Added Successfully";
        }
        public JsonResult fetchrecord()
        {
            List<user_info> st = db.user_info.ToList();
            return Json(st, JsonRequestBehavior.AllowGet);
            
        }
	}
}