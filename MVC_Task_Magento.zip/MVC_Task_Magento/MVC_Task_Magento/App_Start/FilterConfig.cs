﻿using System.Web;
using System.Web.Mvc;

namespace MVC_Task_Magento
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
